<?php
define('PEC_PATH', '/phpEventCalendar_Lite');
//define('PEC_PATH', '/highpitch_event');
//============Generatl Settings
define('DEBUG',false);


//============DB Settings
define('PEC_DB_HOST','localhost');
define('PEC_DB_USER','root');
define('PEC_DB_PASS','');
define('PEC_DB_TYPE','mysql');
define('PEC_DB_NAME','php_event_calendar');
define('PEC_DB_CHARSET','');
/******** DO NOT MODIFY ***********/
require_once('pec.php');
/**********************************/
?>
